var mainChartDisplay = document.getElementById("myAreaChart");
var dashboard = (function () {
    var _messageDivId = '';
    var _cached_units = [];
    var _units_to_display = [
        { name: 'lightSource', labels: [], data: [], color: "rgba(255,247,0" },
        { name: 'inputPump', labels: [], data: [], color: "rgba(0,171,225" },
        { name: 'outputPump', labels: [], data: [], color: "rgba(247,137,40" },
        { name: 'fanIntake', labels: [], data: [], color: "rgba(112,107,250" },
        { name: 'fanExhaus', labels: [], data: [], color: "rgba(250,107,231" },
        { name: 'oxygenPump', labels: [], data: [], color: "rgba(182,168,180" }
    ];
    var _board_filter = [];



    function hideMessages() {
        $('#' + _messageDivId + '').hide();
    }

    function displayError(msg) {
        $('#' + _messageDivId + '').show();
        $('#' + _messageDivId + '').html('<p class="alert alert-danger" role="alert" id="errorDisplay">' + msg + '</p>');
    }

    function displaySuccess(msg) {
        $('#' + _messageDivId + '').show();
        $('#' + _messageDivId + '').html('<p class="alert alert-primary" id="errorDisplay">' + msg + '</p>');
    }

    function init(messageDiv, filter) {
        _messageDivId = messageDiv;
        _board_filter = filter

        hideMessages();
        createFiltersArea(_board_filter);
    }

    function createId(id) { return id + "_control_filter" };

    function createFiltersArea(elements) {
        var controlNames = $('#controlNames');

        function controlTemplate(id, label, value) {
            return '<div class="form-check form-check-inline"\>\
            <input class="form-check-input" type="radio" name="control_templates_radios[]" id="' + id + '"\
        value="'+ value + '\" >\
            <label class="form-check-label" for="'+ id + '">' + label + '</label>\
                    </div >';
        }

        elements.forEach(function (e) {
            var idString = createId(e.name)
            controlNames.append(controlTemplate(idString, e.name, e.show));

            $('#' + idString).prop('checked', e.show == 1 ? true : false);

            $('#' + idString).on('change', function () {
                if ($(this).is(':checked')) {
                    e.show = 1;
                } else {
                    e.show = 0;
                }

               // build();
            })
        })

        var date_from = $('#date_from');
        var date_to = $('#date_to');

        var now = new Date();
        var day = ("0" + now.getDate()).slice(-2);
        var month = ("0" + (now.getMonth() + 1)).slice(-2);
        var today = now.getFullYear() + "-" + (month) + "-" + (day);

        date_from.val(today);
        date_to.val(today);

        date_from.on('change', function () {
            // Get the selected date value
            var selectedDate = $(this).val();

            // Display the selected date in a specific format (you can adjust the format)
            var formattedDate = new Date(selectedDate);

            _board_filter.forEach(function (e) {
                e.from = formattedDate.getFullYear() + '-' + formattedDate.getMonth() + '-' + formattedDate.getDate();
            })

            //build();
        });

        date_to.on('change', function () {
            // Get the selected date value
            var selectedDate = $(this).val();

            // Display the selected date in a specific format (you can adjust the format)
            var formattedDate = new Date(selectedDate);

            _board_filter.forEach(function (e) {
                e.to = formattedDate.getFullYear() + '-' + formattedDate.getMonth() + '-' + formattedDate.getDate();
            })

            //build();
        });

    }

    function checkCache() {

    }

    function processData(data) {
        var dataLines = data.split("\n");
        for (var lineIndexInDataRow = 0; lineIndexInDataRow < dataLines.length; lineIndexInDataRow++) {

            var splitLineOfData = dataLines[lineIndexInDataRow].split("/");

            // Date
            var parsedDataFromLine = splitLineOfData[0] + ":" + splitLineOfData[1] + ":" + splitLineOfData[2];

            // Time
            var parsedTimeFromLine = splitLineOfData[3] + ":" + splitLineOfData[4] + ":" + splitLineOfData[5]; // Extracted date

            var dataObject = JSON.parse(splitLineOfData[6]);

            // The Controls in this line of data
            var controls = dataObject.devices;

            // For each control in data line
            for (var controlInDataLine = 0; controlInDataLine < controls.length; controlInDataLine++) {
                var control = controls[controlInDataLine];

                for (var k = 0; k < _units_to_display.length; k++) {
                    var selected_unit = _units_to_display[k];

                    if (selected_unit.name == control.unit) {
                        _units_to_display[k].labels.push(parsedTimeFromLine);
                        _units_to_display[k].data.push(control);// data = [ [] ,[], ]
                    }
                }
            }
        }
    }

    function createDatasets(filter) {
        var datasets = [];
        var labels = [];

        _units_to_display.forEach(function (unit) {        
            if (unit.name == filter.name) {
                unit.labels.forEach(function (e) {
                    labels.push(e);
                })

                // Apply Filters Here
                var currentData = unit.data.map(function (i) {
                    return i.status;
                });

                datasets.push({
                    label: unit.name,
                    lineTension: 0.3,
                    backgroundColor: unit.color + ",0.2)",
                    borderColor: unit.color + ",1)",
                    pointRadius: 5,
                    pointBackgroundColor: unit.color + ",1)",
                    pointBorderColor: "rgba(255,255,255,0.8)",
                    pointHoverRadius: 5,
                    pointHoverBackgroundColor: unit.color + ",1)",
                    pointHitRadius: 50,
                    pointBorderWidth: 2,
                    data: currentData,
                })
            }
        })

        return {
            datasets: datasets,
            labels: labels
        }


    }

    function formatDataset(data) {
        var datasets = [];
        var labels = [];

        data.forEach(function (s) {
            s.labels.forEach(function (ss) {
                labels.push(ss);
            })

            s.datasets.forEach(function (ss) {
                datasets.push(ss);
            })
        })

        return {
            datasets: datasets,
            labels: labels
        }
    }

    function activateUnit(e) {
        var from = new Date(e.from);
        var to = new Date(e.to);
        var datasets = [];

        // Full compare makes things work fine
        while (from.getDate() <= to.getDate() && from.getMonth() <= to.getMonth() && from.getFullYear() <= to.getFullYear()) {

            // $.ajax({
            //     url: "/get-history?name=" + e.name + "&d=" + from.getDate() + "&m=" + from.getMonth() + "&y=" + from.getFullYear(), // TODO: Parse datetime
            //     type: "GET",
            //     success: function (data, status, xhr) {
            //         processData(data);
            // YEAR-MONTH_DAY
            processData('2023/09/27/17/23/22/{"sensors":{"temperature":25,"humidity":50,"waterTankLevel":13},"devices":[{"status":1,"unit":"lightSource","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":0,"unit":"inputPump","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":1,"unit":"outputPump","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":0,"unit":"fanIntake","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":0,"unit":"fanExhaus","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":1,"unit":"oxygenPump","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}}]}\n2023/09/27/18/23/22/{"sensors":{"temperature":25,"humidity":50,"waterTankLevel":13},"devices":[{"status":1,"unit":"lightSource","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":0,"unit":"inputPump","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":1,"unit":"outputPump","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":0,"unit":"fanIntake","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":0,"unit":"fanExhaus","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":1,"unit":"oxygenPump","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}}]}');
            //         displaySuccess("Loaded");
            //         // Testing One by One
            datasets.push(createDatasets(e));
            //     },
            //     error: function (jqXhr, textStatus, errorMessage) { // error callback 
            //         displayError(errorMessage);
            //     }
            // });

            from.setDate(from.getDate() + 1)
        }

        return formatDataset(datasets);

       
    }

    function drawUnit(data){
        var ds = data.map(function(e){
            return e.datasets.map(function(o){
                return {
                    type: 'line',
                    label: o.label,
                    data: o.data,
                    borderColor: 'rgb(255, 99, 132)',
                    backgroundColor: 'rgba(255, 99, 132, 0.2)'
                }
            })[0]
        })

        // data.forEach(function(e){
            var myAreaChart = new Chart(mainChartDisplay, {
                type: 'line',
                data: {
                    labels: data.map(function(l){
                        return l.labels
                    })[0],
                    datasets: ds
                },
                options: {
                    scales: {
                        xAxes: [{
                            time: {
                                unit: 'date' 
                            },
                            gridLines: {
                                display: false
                            },
                            ticks: {
                                maxTicksLimit: 7
                            }
                        }],
                        yAxes: [{
                            ticks: {
                                min: 0,
                                max: 1,
                                maxTicksLimit: 5
                            },
                            gridLines: {
                                color: "rgba(0, 0, 0, .125)",
                            }
                        }],
                    },
                    legend: {
                        display: true
                    }
                }
            });

            myAreaChart.update();
        // })
        
    }


    
    function cleanUnitsData() {
        for (var k = 0; k < _units_to_display.length; k++) {
            _units_to_display[k].labels = [];
            _units_to_display[k].data = [];
        }
    }

    function build() {
        var data = [];
        _board_filter.forEach(function (e) {
            var timeDelay = 1000;
            if (e.show == 1) {
                cleanUnitsData();
                data.push(activateUnit(e));
            }       
        })

        drawUnit(data);
    }

    return {
        init: init,
        build: build
    }
})();


$(function () {
    // Set new default font family and font color to mimic Bootstrap's default styling
    Chart.defaults.global.defaultFontFamily = '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
    Chart.defaults.global.defaultFontColor = '#292b2c';

    var initial_filter = [
        { show: 1, name: 'lightSource', labels: [], data: [], from: '2023-09-26', to: '2023-09-26' },
        { show: 1, name: 'inputPump', labels: [], data: [], from: '2023-09-26', to: '2023-09-26' },
        { show: 1, name: 'outputPump', labels: [], data: [], from: '2023-09-26', to: '2023-09-26' },
        { show: 1, name: 'fanIntake', labels: [], data: [], from: '2023-09-26', to: '2023-09-26' },
        { show: 1, name: 'fanExhaus', labels: [], data: [], from: '2023-09-26', to: '2023-09-26' },
        { show: 1, name: 'oxygenPump', labels: [], data: [], from: '2023-09-26', to: '2023-09-26' }
    ];


    var from = ''; // get from field
    var to = ''; // get to field

    // Passing filter dashboard knows how to handle display
    dashboard.init('dashboardMSGDiv', initial_filter);
    dashboard.build();

    // Add Event Handlers
})