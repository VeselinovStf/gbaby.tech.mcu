var _messageDivId = 'dashboardMSGDiv';
var mainChartDisplay = document.getElementById("myAreaChart");

function hideMessages() {
    $('#' + _messageDivId + '').hide();
}

function displayError(msg) {
    $('#' + _messageDivId + '').show();
    $('#' + _messageDivId + '').html('<p class="alert alert-danger" role="alert" id="errorDisplay">' + msg + '</p>');
}

function displaySuccess(msg) {
    $('#' + _messageDivId + '').show();
    $('#' + _messageDivId + '').html('<p class="alert alert-primary" id="errorDisplay">' + msg + '</p>');
}

function createId(id) { return id + "_control_filter" };

function createFiltersArea(elements) {
    var controlNames = $('#controlNames');

    function controlTemplate(id, label, value) {
        return '<div class="form-check form-check-inline"\>\
            <input class="form-check-input" type="radio" name="control_templates_radios[]" id="' + id + '"\
        value="'+ value + '\" >\
            <label class="form-check-label" for="'+ id + '">' + label + '</label>\
                    </div >';
    }

    var date_from = $('#date_from');
    var date_to = $('#date_to');

    var now = new Date();
    var day = now.getDate();
    var month = now.getMonth() + 1;
    var today = now.getFullYear() + "-" + (month) + "-" + (day);

    elements.forEach(function (e) {
        e.from = today;
        e.to = today;

        var idString = createId(e.name)
        controlNames.append(controlTemplate(idString, e.name, e.show));

        $('#' + idString).prop('checked', e.show == 1 ? true : false);

        $('#' + idString).on('change', function () {
            if ($(this).is(':checked')) {
                e.show = 1;
            } else {
                e.show = 0;
            }

            // build();
        })
    })


    date_from.val(today);
    date_to.val(today);

    date_from.on('change', function () {
        // Get the selected date value
        var selectedDate = $(this).val();

        // Display the selected date in a specific format (you can adjust the format)
        var formattedDate = new Date(selectedDate);

        _board_filter.forEach(function (e) {
            e.from = formattedDate.getFullYear() + '-' + formattedDate.getMonth() + '-' + formattedDate.getDate();
        })

        //build();
    });

    date_to.on('change', function () {
        // Get the selected date value
        var selectedDate = $(this).val();

        // Display the selected date in a specific format (you can adjust the format)
        var formattedDate = new Date(selectedDate);

        _board_filter.forEach(function (e) {
            e.to = formattedDate.getFullYear() + '-' + formattedDate.getMonth() + '-' + formattedDate.getDate();
        })

        //build();
    });

}


var _units_to_display = [
    { show: 1, name: 'lightSource', labels: [], data: [], color: "rgba(255,247,0", from: '2023-09-27', to: '2023-09-27' },
    { show: 1, name: 'inputPump', labels: [], data: [], color: "rgba(0,171,225", from: '2023-09-27', to: '2023-09-27' },
    { show: 1, name: 'outputPump', labels: [], data: [], color: "rgba(247,137,40", from: '2023-09-27', to: '2023-09-27' },
    { show: 1, name: 'fanIntake', labels: [], data: [], color: "rgba(112,107,250", from: '2023-09-27', to: '2023-09-27' },
    { show: 1, name: 'fanExhaus', labels: [], data: [], color: "rgba(250,107,231", from: '2023-09-27', to: '2023-09-27' },
    { show: 1, name: 'oxygenPump', labels: [], data: [], color: "rgba(182,168,180", from: '2023-09-27', to: '2023-09-27' }
];

function drawUnit() {
    var ds = _units_to_display.map(function (o) {
        return {
            type: 'line',
            label: o.name,
            data: o.data.map(function (d) {
                return d.status
            }),
            borderColor: o.color + ', 132)',
            backgroundColor: 'rgba(255, 99, 132, 0.2)'
        }
    })

    var l = _units_to_display[0].labels
    console.log(l)
    // data.forEach(function(e){
    var myAreaChart = new Chart(mainChartDisplay, {
        type: 'line',
        data: {
            labels: l,
            datasets: ds
        },
        options: {
            scales: {
                xAxes: [{
                    time: {
                        unit: 'date'
                    },
                    gridLines: {
                        display: false
                    },
                    ticks: {
                        maxTicksLimit: 7
                    }
                }],
                yAxes: [{
                    ticks: {
                        min: 0,
                        max: 1,
                        maxTicksLimit: 5
                    },
                    gridLines: {
                        color: "rgba(0, 0, 0, .125)",
                    }
                }],
            },
            legend: {
                display: true
            }
        }
    });

    myAreaChart.update();
    // })

}

function processData(data) {
    var dataLines = data.split("\n");
    for (var lineIndexInDataRow = 0; lineIndexInDataRow < dataLines.length; lineIndexInDataRow++) {
        var splitLineOfData = dataLines[lineIndexInDataRow].split("/");
        // Date
        var parsedDataFromLine = splitLineOfData[0] + ":" + splitLineOfData[1] + ":" + splitLineOfData[2];
        // Time
        var parsedTimeFromLine = splitLineOfData[3] + ":" + splitLineOfData[4] + ":" + splitLineOfData[5]; // Extracted date
        var dataObject = JSON.parse(splitLineOfData[6]);
        // The Controls in this line of data
        var controls = dataObject.devices;
        // For each control in data line
        for (var controlInDataLine = 0; controlInDataLine < controls.length; controlInDataLine++) {
            var control = controls[controlInDataLine];

            var done = false;
            for (var k = 0; k < _units_to_display.length; k++) {
                var selected_unit = _units_to_display[k];

                if (selected_unit.name == control.unit) {
                    _units_to_display[k].labels.push(parsedTimeFromLine);
                    _units_to_display[k].data.push(control);// data = [ [] ,[], ]

                    done = true;
                    break;
                }
            }

            if(done){
                break;
            }
        }
    }
}

function initiateData(e) {
  var from = new Date(e.from);
  var to = new Date(e.to);

    // Full compare makes things work fine
    // while (from.getDate() <= to.getDate() && from.getMonth() <= to.getMonth() && from.getFullYear() <= to.getFullYear()) {

        $.ajax({
            url: "/get-history?name=" + e.name + "&d=" + from.getDate() + "&m=" + from.getMonth() + "&y=" + from.getFullYear(), // TODO: Parse datetime
            type: "GET",
            success: function (data, status, xhr) {
    //processData('2023/8/27/6/10/22/{"sensors":{"temperature":23,"humidity":44,"waterTankLevel":0},"devices":[{"status":1,"unit":"lightSource","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":0,"unit":"inputPump","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":0,"unit":"outputPump","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":0,"unit":"fanIntake","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":0,"unit":"fanExhaus","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":0,"unit":"oxygenPump","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}}]}\n2023/8/27/6/10/26/{"sensors":{"temperature":23,"humidity":44,"waterTankLevel":0},"devices":[{"status":0,"unit":"lightSource","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":0,"unit":"inputPump","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":0,"unit":"outputPump","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":0,"unit":"fanIntake","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":0,"unit":"fanExhaus","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":0,"unit":"oxygenPump","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}}]}');
    // YEAR-MONTH_DAY
    //processData('2023/09/27/17/23/22/{"sensors":{"temperature":25,"humidity":50,"waterTankLevel":13},"devices":[{"status":1,"unit":"lightSource","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":0,"unit":"inputPump","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":1,"unit":"outputPump","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":0,"unit":"fanIntake","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":0,"unit":"fanExhaus","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":1,"unit":"oxygenPump","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}}]}\n2023/09/27/18/23/22/{"sensors":{"temperature":25,"humidity":50,"waterTankLevel":13},"devices":[{"status":1,"unit":"lightSource","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":0,"unit":"inputPump","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":1,"unit":"outputPump","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":0,"unit":"fanIntake","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":0,"unit":"fanExhaus","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":1,"unit":"oxygenPump","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}}]}');
   // displaySuccess("Loaded");
    // Testing One by One
                processData(data);
                drawUnit();
            },
            error: function (jqXhr, textStatus, errorMessage) { // error callback 
                displayError(errorMessage);
            }
        });

    //     from.setDate(from.getDate() + 1)
    // }
    // drawUnit();


}


$(function () {
    // Set new default font family and font color to mimic Bootstrap's default styling
    Chart.defaults.global.defaultFontFamily = '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
    Chart.defaults.global.defaultFontColor = '#292b2c';

    createFiltersArea(_units_to_display);

    //_units_to_display.forEach(function (u) {
        initiateData({
            from: _units_to_display[0].from,
            to: _units_to_display[0].to,
            name: _units_to_display[0].name
        });
    //})

})