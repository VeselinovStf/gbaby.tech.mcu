$(function () {
  // Set new default font family and font color to mimic Bootstrap's default styling
  Chart.defaults.global.defaultFontFamily = '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
  Chart.defaults.global.defaultFontColor = '#292b2c';

  function displayError(msg) {
    $('#dashboardMSGDiv').show();
    $('#dashboardMSGDiv').html('<p class="alert alert-danger" role="alert" id="errorDisplay">' + msg + '</p>');
  }

  function displaySuccess(msg) {
    $('#dashboardMSGDiv').show();
    $('#dashboardMSGDiv').html('<p class="alert alert-primary" id="errorDisplay">' + msg + '</p>');
  }

  function hideMSG() {
    $('#dashboardMSGDiv').hide();
  }
  
  var units_to_display = [
    { name: 'lightSource', labels: [], data: [], color: "rgba(255,247,0" },
    { name: 'inputPump', labels: [], data: [], color: "rgba(0,171,225" },
    { name: 'outputPump', labels: [], data: [], color: "rgba(247,137,40" },
    { name: 'fanIntake', labels: [], data: [], color: "rgba(112,107,250" },
    { name: 'fanExhaus', labels: [], data: [], color: "rgba(250,107,231" },
    { name: 'oxygenPump', labels: [], data: [], color: "rgba(182,168,180" }
  ];

  function formatData(fileContent) {
    // Define a regular expression to extract all date and JSON object pairs
    var lines = fileContent.split("\n");
    var result = [];

    for (var index = 0; index < lines.length; index++) {
      var line = lines[index].split("/");


      var date = line[0] + ":" + line[1] + ":" + line[2]; // Extracted date
      var jsonText = line[3];
      // Now you can parse the JSON object
      var dataObject = JSON.parse(jsonText);

      var controls = dataObject.devices;

      for (var j = 0; j < controls.length; j++) {
        var control = controls[j];

        for (var k = 0; k < units_to_display.length; k++) {
          var selected_unit = units_to_display[k];

          if (selected_unit.name == control.unit) {
            units_to_display[k].labels.push(date);
            units_to_display[k].data.push(control);
          }
        }


      }

    }

  }

  function mapToDOM(data) {

    formatData(data);
    var d = units_to_display[5];
    var values = d.data.map(function (i) {
      return i.status;
    })

    var ctx = document.getElementById("demoChartArea");

    var ds = [];
    for (var i = 0; i < units_to_display.length; i++) {
      ds.push(
        {
          label: units_to_display[i].name,
          lineTension: 0.3,
          backgroundColor: units_to_display[i].color + ",0.2)",
          borderColor: units_to_display[i].color + ",1)",
          pointRadius: 5,
          pointBackgroundColor: units_to_display[i].color + ",1)",
          pointBorderColor: "rgba(255,255,255,0.8)",
          pointHoverRadius: 5,
          pointHoverBackgroundColor: units_to_display[i].color + ",1)",
          pointHitRadius: 50,
          pointBorderWidth: 2,
          data: units_to_display[i].data.map(function (i) {
            return i.status;
          }),
        }
      );

    }

    // Area Chart Example

    var myAreaChart = new Chart(ctx, {
      type: 'line',
      data: {
        labels: d.labels,
        datasets: ds,
      },
      options: {
        scales: {
          xAxes: [{
            time: {
              unit: 'date'
            },
            gridLines: {
              display: false
            },
            ticks: {
              maxTicksLimit: 7
            }
          }],
          yAxes: [{
            ticks: {
              min: 0,
              max: 1,
              maxTicksLimit: 5
            },
            gridLines: {
              color: "rgba(0, 0, 0, .125)",
            }
          }],
        },
        legend: {
          display: true
        }
      }
    });

  }

  function mapRecentDocsToUI(data){
      $('#recentLogs').text(data);
  }

  function recentLogs(){
    $.ajax({
      url: "/get-logs",
      type: "GET",
      success: function (data, status, xhr) {
        mapRecentDocsToUI(data);
        logDisplay.show();
        displaySuccess("Loaded");
      },
      error: function (jqXhr, textStatus, errorMessage) { // error callback 
        displayError(errorMessage);
      }
    });
  }

  hideMSG();
  // for (var i = 0; i < units_to_display.length; i++) {
  //   $.ajax({
  //     url: "/get-history?name=" + units_to_display[i].name + "&d=" + 24 + "&m=" + 8 + "&y=" + 2023, // TODO: Parse datetime
  //     type: "GET",
  //     success: function (data, status, xhr) {
  //       mapToDOM(data);
  //       displaySuccess("Loaded");
  //     },
  //     error: function (jqXhr, textStatus, errorMessage) { // error callback 
  //       displayError(errorMessage);
  //     }
  //   });
  // }

 
 mapToDOM('5/44/14/{"sensors":{"temperature":25,"humidity":50,"waterTankLevel":13},"devices":[{"status":1,"unit":"lightSource","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":0,"unit":"inputPump","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":1,"unit":"outputPump","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":0,"unit":"fanIntake","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":0,"unit":"fanExhaus","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":0,"unit":"oxygenPump","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}}]}\n5/44/12/{"sensors":{"temperature":25,"humidity":49,"waterTankLevel":12},"devices":[{"status":1,"unit":"lightSource","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":1,"unit":"inputPump","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":1,"unit":"outputPump","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":0,"unit":"fanIntake","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":0,"unit":"fanExhaus","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}},{"status":1,"unit":"oxygenPump","rule":0,"onWhen":{"rule":0,"condition":0,"value":0},"offWhen":{"rule":0,"condition":0,"value":0}}]}');

});
